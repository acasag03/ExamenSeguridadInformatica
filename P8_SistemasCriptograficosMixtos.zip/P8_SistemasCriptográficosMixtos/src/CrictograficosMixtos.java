import java.math.BigInteger;

public class CrictograficosMixtos
{
	public static void main(String[] args)
	{
		
	}
}
